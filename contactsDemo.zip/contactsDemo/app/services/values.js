angular.module('directoryApp').value('appSettings', {
    title: 'Business Directories',
    version: '1.0'
});

